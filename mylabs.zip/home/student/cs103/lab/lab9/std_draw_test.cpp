#include "bmplib3.h"

int main() {
   std_draw_line(orange, 0, 0, 255, 255);
   std_draw_line(red, 0, 255, 255, 0);
   std_show();
   return 0;
}
