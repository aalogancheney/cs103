#include "bigint.h"
#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
  BigInt a("10");
  
  int b = a.vInt[1];
  
  cout << b << endl;
  
  return 0;
}
