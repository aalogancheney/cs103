#include "bigint.h"
using namespace std;

int main() {
   BigInt myInt("103");
   myInt.println();
   return 0;
}
