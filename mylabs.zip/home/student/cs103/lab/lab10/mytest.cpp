#include "bigint.h"
using namespace std;

int main(int argc, char* argv[]) {
  BigInt myint("101342342400");
  myint.println();
  return 0;
}
